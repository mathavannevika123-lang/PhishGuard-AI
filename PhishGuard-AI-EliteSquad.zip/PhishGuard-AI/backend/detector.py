"""
PhishGuard AI - Hybrid Detection Engine
Combines Machine Learning (Random Forest & TF-IDF Logistic Regression)
with transparent rule-based heuristic engines, domain intelligence,
and an Explainable AI (XAI) reasoning pipeline.
"""

import os
import re
import math
import joblib
from urllib.parse import urlparse
from typing import Dict, Any, List, Optional
from datetime import datetime

MODEL_DIR = os.path.join(os.path.dirname(__file__), "saved_models")
URL_MODEL_PATH = os.path.join(MODEL_DIR, "url_classifier.joblib")
TEXT_MODEL_PATH = os.path.join(MODEL_DIR, "text_pipeline.joblib")

# Load models if available
url_classifier = None
text_pipeline = None

try:
    if os.path.exists(URL_MODEL_PATH):
        url_classifier = joblib.load(URL_MODEL_PATH)
    if os.path.exists(TEXT_MODEL_PATH):
        text_pipeline = joblib.load(TEXT_MODEL_PATH)
except Exception as e:
    print(f"[Detector] Warning loading models: {e}")

# Whitelisted root domains (Exact match or verified official domain)
LEGIT_DOMAINS = {
    "google.com", "github.com", "wikipedia.org", "amazon.com", "microsoft.com",
    "apple.com", "netflix.com", "linkedin.com", "spotify.com", "fastapi.tiangolo.com",
    "stackoverflow.com", "pypi.org", "python.org", "youtube.com", "facebook.com",
    "instagram.com", "twitter.com", "x.com", "dropbox.com", "zoom.us", "slack.com",
    "harvard.edu", "mit.edu", "stanford.edu", "gov.in", "usa.gov", "nih.gov", "who.int"
}

POPULAR_BRANDS = {
    "paypal": ["paypal.com"],
    "apple": ["apple.com", "icloud.com"],
    "microsoft": ["microsoft.com", "live.com", "office.com"],
    "google": ["google.com", "gmail.com"],
    "amazon": ["amazon.com", "amazon.in"],
    "netflix": ["netflix.com"],
    "chase": ["chase.com"],
    "wellsfargo": ["wellsfargo.com"],
    "bankofamerica": ["bankofamerica.com"],
    "sbi": ["sbi.co.in", "onlinesbi.sbi"],
    "hdfc": ["hdfcbank.com"],
    "icici": ["icicibank.com"],
    "binance": ["binance.com"],
    "coinbase": ["coinbase.com"],
    "fedex": ["fedex.com"],
    "dhl": ["dhl.com"],
    "usps": ["usps.com"],
    "telegram": ["telegram.org", "t.me"],
    "whatsapp": ["whatsapp.com"],
    "instagram": ["instagram.com"]
}

SUSPICIOUS_TLDS = {
    "xyz", "top", "buzz", "club", "tk", "ml", "ga", "cf", "gq",
    "work", "icu", "sbs", "cfd", "click", "link", "monster", "online",
    "site", "rest", "cam", "kim", "fit", "surf", "cn", "ru"
}

# ---------------------------------------------------------------------------
# URL DETECTION HELPER FUNCTIONS
# ---------------------------------------------------------------------------
def extract_url_features_vector(url: str) -> list:
    if not url.startswith(("http://", "https://")):
        url = "http://" + url
    parsed = urlparse(url)
    hostname = (parsed.hostname or "").lower()
    full_url = url.lower()
    
    length = len(full_url)
    host_length = len(hostname)
    num_dots = hostname.count(".")
    num_hyphens = hostname.count("-")
    num_at = full_url.count("@")
    num_question = full_url.count("?")
    num_equal = full_url.count("=")
    num_slashes = full_url.count("/")
    is_ip = 1.0 if re.match(r"^(\d{1,3}\.){3}\d{1,3}$", hostname) else 0.0
    
    prob = [float(hostname.count(c)) / len(hostname) for c in set(hostname)] if hostname else [0]
    entropy = -sum(p * math.log(p, 2) for p in prob) if hostname else 0.0
    
    subdomains = hostname.split(".")
    tld = subdomains[-1] if len(subdomains) > 1 else ""
    is_suspicious_tld = 1.0 if tld in SUSPICIOUS_TLDS else 0.0
    subdomain_count = max(0, len(subdomains) - 2)
    brand_mentions = sum(1.0 for brand in POPULAR_BRANDS if brand in full_url)
    keywords = ["login", "signin", "verify", "update", "bank", "account", "secure", "wallet", "free", "gift", "bonus", "claim"]
    keyword_count = sum(1.0 for kw in keywords if kw in full_url)
    is_https = 1.0 if parsed.scheme == "https" else 0.0
    
    return [
        length, host_length, num_dots, num_hyphens, num_at, num_question,
        num_equal, num_slashes, is_ip, entropy, is_suspicious_tld,
        subdomain_count, brand_mentions, keyword_count, is_https
    ]

def analyze_url(url: str) -> Dict[str, Any]:
    """Analyzes a URL using hybrid ML + Rules + Explainable AI."""
    cleaned_url = url.strip()
    if not cleaned_url.startswith(("http://", "https://")):
        processed_url = "http://" + cleaned_url
    else:
        processed_url = cleaned_url
        
    parsed = urlparse(processed_url)
    hostname = (parsed.hostname or "").lower()
    path = parsed.path.lower()
    query = parsed.query.lower()
    full_str = processed_url.lower()
    
    reasons = []
    highlights = []
    signals = []
    rule_score_delta = 0
    
    # Check if host is in verified whitelist
    for legit in LEGIT_DOMAINS:
        if hostname == legit or hostname.endswith("." + legit):
            # Check for path spoofing or suspicious params
            if not any(k in path for k in [".apk", ".exe", "free-money"]):
                return {
                    "input": cleaned_url,
                    "type": "url",
                    "risk_score": 3,
                    "classification": "SAFE",
                    "confidence": 99.2,
                    "summary": f"Verified official domain belonging to {legit}. SSL/TLS and hostname trust checks passed with zero threat indicators.",
                    "reasons": [
                        {"factor": "Domain Authority", "severity": "SAFE", "description": f"Domain '{hostname}' is a verified reputable service."},
                        {"factor": "Legitimate Host", "severity": "SAFE", "description": "No impersonation, phishing redirection, or homoglyph patterns detected."}
                    ],
                    "factors": {
                        "domain_trust": 98,
                        "structural_safety": 95,
                        "brand_integrity": 100,
                        "protocol_security": 96
                    },
                    "highlights": [],
                    "actions": [
                        "Safe to proceed: Site belongs to an established legitimate provider.",
                        "Standard best practice: Ensure you see the lock icon in your address bar."
                    ],
                    "analyzed_at": datetime.utcnow().isoformat()
                }

    # 1. IP address check
    is_ip = bool(re.match(r"^(\d{1,3}\.){3}\d{1,3}$", hostname))
    if is_ip:
        rule_score_delta += 40
        reasons.append({
            "factor": "Raw IP Hostname",
            "severity": "CRITICAL",
            "description": f"Uses raw IP address ({hostname}) instead of a verified registered domain. Frequently used in evasive botnet phishing kits."
        })
        signals.append("Raw IP address used in host")
        highlights.append(hostname)

    # 2. Suspicious TLD
    subdomains = hostname.split(".")
    tld = subdomains[-1] if len(subdomains) > 1 else ""
    if tld in SUSPICIOUS_TLDS:
        rule_score_delta += 30
        reasons.append({
            "factor": "High-Risk Domain Extension",
            "severity": "HIGH",
            "description": f"Uses '.{tld}' top-level domain, commonly associated with burner domains, malware distribution, and zero-day phishing campaigns."
        })
        signals.append(f"High-risk TLD (.{tld})")
        highlights.append(f".{tld}")

    # 3. Brand Impersonation / Typosquatting
    brand_impersonated = None
    for brand, legit_domains in POPULAR_BRANDS.items():
        if brand in full_str:
            is_legit = any(hostname == ld or hostname.endswith("." + ld) for ld in legit_domains)
            if not is_legit:
                brand_impersonated = brand
                rule_score_delta += 45
                reasons.append({
                    "factor": "Brand Impersonation / Spoofing",
                    "severity": "CRITICAL",
                    "description": f"Impersonates target brand '{brand.title()}' on an unverified domain ('{hostname}'). Highly indicative of credential harvesting."
                })
                signals.append(f"Impersonating {brand.title()}")
                highlights.append(brand)
                break

    # 4. Homoglyphs & Leetspeak (e.g. paypa1, micros0ft, amzon, goog1e)
    leetspeak_map = [
        (r"paypa[l1i]", "PayPal"),
        (r"micros[o0]ft", "Microsoft"),
        (r"arnazon|amaz0n", "Amazon"),
        (r"wellsfarg[o0]", "Wells Fargo"),
        (r"netfl[i1]x", "Netflix")
    ]
    for pattern, brand_name in leetspeak_map:
        if re.search(pattern, hostname) and not any(hostname.endswith(d) for d in [f"{brand_name.lower().replace(' ', '')}.com"]):
            rule_score_delta += 40
            reasons.append({
                "factor": "Typosquatting / Character Substitution",
                "severity": "CRITICAL",
                "description": f"Domain contains deceptive spelling designed to mimic '{brand_name}' using lookalike characters."
            })
            signals.append("Typosquatting detected")

    # 5. Excessive subdomains or deceptive subdomain chaining (e.g. paypal.com.verify-user.top)
    if len(subdomains) > 3:
        rule_score_delta += 20
        reasons.append({
            "factor": "Deceptive Subdomain Stacking",
            "severity": "MEDIUM",
            "description": f"Contains {len(subdomains)} domain segments. Attackers stack subdomains to trick mobile browser URL preview bars."
        })
        signals.append("Subdomain stacking")

    # 6. Sensitive keywords in path/query (login, signin, verify, kyc, secure)
    sensitive_keywords = ["login", "signin", "verify", "update", "bank", "account", "secure", "wallet", "apk", "billing", "kyc"]
    found_keywords = [kw for kw in sensitive_keywords if kw in full_str]
    if found_keywords:
        rule_score_delta += min(25, len(found_keywords) * 10)
        reasons.append({
            "factor": "Credential Harvesting Keywords",
            "severity": "HIGH" if brand_impersonated else "MEDIUM",
            "description": f"URL targets sensitive actions with keywords: {', '.join(found_keywords)}."
        })
        signals.append(f"Keywords: {', '.join(found_keywords[:3])}")
        highlights.extend(found_keywords)

    # 7. Unencrypted HTTP with sensitive actions
    if parsed.scheme == "http" and (brand_impersonated or found_keywords):
        rule_score_delta += 15
        reasons.append({
            "factor": "Insecure Protocol (HTTP)",
            "severity": "HIGH",
            "description": "Sensitive login/verification portal transmitted over unencrypted HTTP protocol."
        })
        signals.append("Plain HTTP protocol")

    # 8. ML Model inference
    ml_prob = 0.5
    if url_classifier is not None:
        try:
            feats = extract_url_features_vector(cleaned_url)
            ml_prob = float(url_classifier.predict_proba([feats])[0][1])
        except Exception as e:
            print(f"[Detector] ML predict error: {e}")

    # Combine ML probability (40%) + Rule score delta (60%)
    base_ml_score = ml_prob * 100
    final_score = int(min(99, max(5, (base_ml_score * 0.4) + (min(100, rule_score_delta) * 0.6))))
    
    # Floor / Ceiling enforcement based on clear rules
    if brand_impersonated and tld in SUSPICIOUS_TLDS:
        final_score = max(final_score, 88)
    elif is_ip and found_keywords:
        final_score = max(final_score, 92)

    # Classification tier
    if final_score >= 70:
        classification = "DANGEROUS"
    elif final_score >= 30:
        classification = "SUSPICIOUS"
    else:
        classification = "SAFE"

    # Threat radar factors (0 to 100 risk)
    factors = {
        "domain_trust": max(5, 100 - (rule_score_delta * 1.1)),
        "brand_integrity": 15 if brand_impersonated else (60 if found_keywords else 95),
        "structural_safety": max(10, 100 - (len(subdomains) * 18 + (30 if is_ip else 0))),
        "protocol_security": 20 if parsed.scheme == "http" else 90
    }

    # Actionable guidance
    if classification == "DANGEROUS":
        actions = [
            "DO NOT click this link or submit any passwords, card numbers, or OTPs.",
            "If you already entered information, immediately change your password on the official website.",
            "Report this malicious link to the national cybersecurity portal or anti-phishing workgroup."
        ]
        summary = f"High-confidence phishing hazard detected. This URL attempts to deceive users with impersonation and evasive hosting structures."
    elif classification == "SUSPICIOUS":
        actions = [
            "Exercise caution: Verify the domain name carefully before taking any action.",
            "Do not enter personal or payment credentials on this unverified page.",
            "Navigate directly to the organization's official website instead of using this link."
        ]
        summary = f"Suspicious characteristics observed. URL exhibits indicators commonly seen in unverified promotions or tracking redirects."
    else:
        actions = [
            "The URL appears structurally consistent with legitimate web destinations.",
            "Always verify you are on HTTPS before submitting private details."
        ]
        summary = "No anomalous phishing signatures or deceptive patterns were found for this URL."

    return {
        "input": cleaned_url,
        "type": "url",
        "risk_score": final_score,
        "classification": classification,
        "confidence": round(85.0 + (abs(final_score - 50) * 0.28), 1),
        "summary": summary,
        "reasons": reasons if reasons else [{"factor": "Baseline Security", "severity": "SAFE", "description": "Standard URL syntax with no malicious traits."}],
        "factors": factors,
        "highlights": list(set(highlights)),
        "actions": actions,
        "analyzed_at": datetime.utcnow().isoformat()
    }

# ---------------------------------------------------------------------------
# MESSAGE / SMS / CHAT SCAM ANALYZER
# ---------------------------------------------------------------------------
URGENCY_REGEX = re.compile(
    r"\b(urgent|immediately|within \d+ (hours?|mins?|days?)|blocked|suspended|deactivated|terminated|expir(es?|ing) today|act now|last (call|warning|chance)|final notice|disconnect(ed)?|freeze|frozen)\b",
    re.IGNORECASE
)

FINANCIAL_REGEX = re.compile(
    r"\b(won|lottery|cash prize|bitcoin|crypto|free iphone|airdrop|\$\d+[\d,]*|₹\d+[\d,]*|grant of|refund of|earn \$\d+|congratulations winner|bonus deposit|guaranteed profit|exclusive gift)\b",
    re.IGNORECASE
)

COERCION_REGEX = re.compile(
    r"\b(arrest warrant|court summons|police complaint|legal action|investigation|penalty|fine of|fbi|tax department|customs officer|jail|law enforcement|enforcement directorate)\b",
    re.IGNORECASE
)

CREDENTIAL_REGEX = re.compile(
    r"\b(verify kyc|update pan|enter otp|share otp|confirm password|bank credentials|card details|cvv|social security|aadhaar|netbanking|secret pin|seed phrase|private key)\b",
    re.IGNORECASE
)

IMPERSONATION_REGEX = re.compile(
    r"\b(sbi|hdfc|icici|chase|wells fargo|bank of america|paypal|netflix|amazon customer|usps|dhl|fedex|electricity board|customer care|hr manager|telegram manager|support team)\b",
    re.IGNORECASE
)

CTA_REGEX = re.compile(
    r"\b(click here|click link|download apk|install file|call this number|call immediately|reply with|send gift card|contact on telegram)\b",
    re.IGNORECASE
)

def analyze_message(text: str) -> Dict[str, Any]:
    """Analyzes text/SMS/chat messages for social engineering, coercion & scam indicators."""
    cleaned = text.strip()
    reasons = []
    highlights = []
    rule_score_delta = 0
    signals = []

    # 1. Urgency / Panic induction
    urgency_matches = URGENCY_REGEX.findall(cleaned)
    if urgency_matches:
        # Extract matched words
        matched_words = [m[0] if isinstance(m, tuple) else m for m in urgency_matches]
        rule_score_delta += 28
        reasons.append({
            "factor": "Urgency & Artificial Panic",
            "severity": "HIGH",
            "description": f"Uses psychological pressure ({', '.join(set(matched_words[:3]))}) to force hurried action without critical thinking."
        })
        signals.append("High urgency tactics")
        highlights.extend(matched_words)

    # 2. Financial Bait / Unrealistic Rewards
    financial_matches = FINANCIAL_REGEX.findall(cleaned)
    if financial_matches:
        matched_words = [m[0] if isinstance(m, tuple) else m for m in financial_matches]
        rule_score_delta += 32
        reasons.append({
            "factor": "Financial / Lottery Bait",
            "severity": "HIGH",
            "description": f"Promises unrealistic rewards or sudden windfalls ({', '.join(set(matched_words[:3]))}) typical of advance-fee and task scams."
        })
        signals.append("Lottery/Reward bait")
        highlights.extend(matched_words)

    # 3. Legal Coercion & Intimidation
    coercion_matches = COERCION_REGEX.findall(cleaned)
    if coercion_matches:
        matched_words = [m[0] if isinstance(m, tuple) else m for m in coercion_matches]
        rule_score_delta += 45
        reasons.append({
            "factor": "Authoritarian Intimidation",
            "severity": "CRITICAL",
            "description": f"Employs legal/police threats ({', '.join(set(matched_words[:3]))}) to frighten recipients into compliance."
        })
        signals.append("Legal extortion threats")
        highlights.extend(matched_words)

    # 4. Credential / Sensitive Data Theft
    credential_matches = CREDENTIAL_REGEX.findall(cleaned)
    if credential_matches:
        matched_words = [m[0] if isinstance(m, tuple) else m for m in credential_matches]
        rule_score_delta += 40
        reasons.append({
            "factor": "Credential & Identity Harvesting",
            "severity": "CRITICAL",
            "description": f"Sollicits sensitive credentials ({', '.join(set(matched_words[:3]))}) which authorized institutions will NEVER request via casual messaging."
        })
        signals.append("Credential/OTP solicitation")
        highlights.extend(matched_words)

    # 5. Entity Impersonation
    impersonation_matches = IMPERSONATION_REGEX.findall(cleaned)
    if impersonation_matches:
        matched_words = [m[0] if isinstance(m, tuple) else m for m in impersonation_matches]
        rule_score_delta += 25
        reasons.append({
            "factor": "Brand / Authority Impersonation",
            "severity": "HIGH",
            "description": f"Poses as reputable entity ({', '.join(set(matched_words[:3]))}) to build unearned trust."
        })
        signals.append("Authority impersonation")
        highlights.extend(matched_words)

    # 6. Call to Action / Dangerous instruction
    cta_matches = CTA_REGEX.findall(cleaned)
    if cta_matches:
        matched_words = [m[0] if isinstance(m, tuple) else m for m in cta_matches]
        rule_score_delta += 20
        reasons.append({
            "factor": "Manipulative Call-To-Action",
            "severity": "MEDIUM",
            "description": f"Directs user to execute dangerous actions ({', '.join(set(matched_words[:2]))})."
        })
        signals.append("High-risk call to action")
        highlights.extend(matched_words)

    # 7. Check for embedded URLs in message
    url_pattern = r"(https?://[^\s]+|www\.[^\s]+|[a-zA-Z0-9-]+\.(?:xyz|top|buzz|sbs|cfd|club|link|online|rest)[^\s]*)"
    urls_found = re.findall(url_pattern, cleaned)
    embedded_url_result = None
    if urls_found:
        first_url = urls_found[0]
        embedded_url_result = analyze_url(first_url)
        if embedded_url_result["classification"] in ["DANGEROUS", "SUSPICIOUS"]:
            rule_score_delta += 35
            reasons.append({
                "factor": "Malicious Embedded Link",
                "severity": "CRITICAL",
                "description": f"Message contains link to '{first_url}' flagged as {embedded_url_result['classification']} (Risk: {embedded_url_result['risk_score']}/100)."
            })
            highlights.append(first_url)

    # ML Text Pipeline Inference
    ml_prob = 0.5
    if text_pipeline is not None:
        try:
            ml_prob = float(text_pipeline.predict_proba([cleaned])[0][1])
        except Exception as e:
            print(f"[Detector] NLP ML inference error: {e}")

    base_ml_score = ml_prob * 100
    final_score = int(min(99, max(4, (base_ml_score * 0.4) + (min(100, rule_score_delta) * 0.6))))

    # Coercion or credential theft with fake link should guarantee high risk
    if (coercion_matches or credential_matches) and (urls_found or urgency_matches):
        final_score = max(final_score, 85)

    if final_score >= 70:
        classification = "DANGEROUS"
    elif final_score >= 30:
        classification = "SUSPICIOUS"
    else:
        classification = "SAFE"

    # Social engineering factors for radar/bars
    factors = {
        "urgency_intensity": min(100, len(urgency_matches) * 45 + (20 if "immediately" in cleaned.lower() else 0)),
        "impersonation_index": min(100, len(impersonation_matches) * 50),
        "credential_theft_risk": min(100, len(credential_matches) * 55),
        "social_engineering": min(100, len(coercion_matches) * 50 + len(financial_matches) * 40)
    }

    if classification == "DANGEROUS":
        actions = [
            "DO NOT reply to this message, download any attachments/APKs, or click links.",
            "NEVER disclose OTPs, PINs, card numbers, or passwords over SMS or chat.",
            "Block the sender's phone number or account immediately.",
            "Verify independently via the official helpline or website of the named company."
        ]
        summary = "Dangerous scam message detected. Strong social-engineering tactics detected aimed at stealing credentials or money."
    elif classification == "SUSPICIOUS":
        actions = [
            "Be cautious: Unverified promotions or generic account warnings often conceal scams.",
            "Do not follow instructions in the message without independently checking your account.",
            "Look up the official contact details directly through a search engine or official app."
        ]
        summary = "Message displays suspicious patterns such as elevated urgency or promotional bait."
    else:
        actions = [
            "The message does not display obvious scam or coercion patterns.",
            "Always follow standard digital hygiene and never share one-time passcodes."
        ]
        summary = "No alarming social-engineering or phishing triggers were found in this text."

    return {
        "input": cleaned,
        "type": "message",
        "risk_score": final_score,
        "classification": classification,
        "confidence": round(84.0 + (abs(final_score - 50) * 0.29), 1),
        "summary": summary,
        "reasons": reasons if reasons else [{"factor": "Content Integrity", "severity": "SAFE", "description": "Message phrasing is typical of normal communication."}],
        "factors": factors,
        "highlights": list(set(highlights)),
        "embedded_url_analysis": embedded_url_result,
        "actions": actions,
        "analyzed_at": datetime.utcnow().isoformat()
    }

# ---------------------------------------------------------------------------
# EMAIL RISK ANALYZER
# ---------------------------------------------------------------------------
def analyze_email(sender: str, subject: str, body: str) -> Dict[str, Any]:
    """Analyzes email headers, subject urgency, spoofing signals, and body content."""
    reasons = []
    highlights = []
    rule_score_delta = 0
    signals = []

    # 1. Parse sender display name vs actual email address
    # E.g. "PayPal Security <noreply@secure-alert-service.xyz>"
    display_name = ""
    email_addr = sender.strip()
    match = re.match(r"^([^<]+)<([^>]+)>$", sender.strip())
    if match:
        display_name = match.group(1).strip()
        email_addr = match.group(2).strip()

    sender_domain = email_addr.split("@")[-1].lower() if "@" in email_addr else ""
    
    # Check display name spoofing
    for brand, legit_domains in POPULAR_BRANDS.items():
        if brand in display_name.lower() or brand in sender.lower():
            is_legit_domain = any(sender_domain == ld or sender_domain.endswith("." + ld) for ld in legit_domains)
            if not is_legit_domain:
                rule_score_delta += 48
                reasons.append({
                    "factor": "Sender Display Name Spoofing",
                    "severity": "CRITICAL",
                    "description": f"Display name poses as '{brand.title()}' but is dispatched from untrusted domain '@{sender_domain}'."
                })
                signals.append("Sender spoofing detected")
                highlights.append(display_name)
                highlights.append(sender_domain)
                break

    # Check free webmail pretending to be organization
    free_providers = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "aol.com"]
    if sender_domain in free_providers:
        org_keywords = ["support", "security", "billing", "service", "admin", "official", "helpdesk", "bank"]
        if any(k in display_name.lower() or k in email_addr.lower() for k in org_keywords):
            rule_score_delta += 35
            reasons.append({
                "factor": "Free Webmail Impersonation",
                "severity": "HIGH",
                "description": f"Official institution impersonated using a consumer free webmail provider (@{sender_domain})."
            })
            signals.append("Free webmail used for corporate persona")

    # 2. Subject Line Analysis
    subject_caps_ratio = sum(1 for c in subject if c.isupper()) / max(1, len(subject))
    if subject_caps_ratio > 0.4 and len(subject) > 10:
        rule_score_delta += 20
        reasons.append({
            "factor": "Excessive Subject Urgency / All-Caps",
            "severity": "MEDIUM",
            "description": "Subject line uses aggressive capital letters and urgent phrasing designed to spark panic."
        })
        signals.append("Urgent all-caps subject")

    # 3. Analyze Body using Message NLP Engine
    full_text_to_analyze = f"{subject}\n\n{body}"
    body_analysis = analyze_message(full_text_to_analyze)

    # Extract reasons from body
    for r in body_analysis["reasons"]:
        if r["factor"] != "Content Integrity":
            reasons.append(r)
    highlights.extend(body_analysis["highlights"])

    # Score fusion
    combined_score = int(min(99, max(5, (body_analysis["risk_score"] * 0.6) + (rule_score_delta * 0.5))))
    
    if any(r["severity"] == "CRITICAL" for r in reasons):
        combined_score = max(combined_score, 82)

    if combined_score >= 70:
        classification = "DANGEROUS"
    elif combined_score >= 30:
        classification = "SUSPICIOUS"
    else:
        classification = "SAFE"

    factors = {
        "sender_reputation": max(5, 100 - (rule_score_delta * 1.2)),
        "content_safety": max(5, 100 - body_analysis["risk_score"]),
        "social_engineering": body_analysis["factors"]["social_engineering"],
        "link_risk": body_analysis["embedded_url_analysis"]["risk_score"] if body_analysis["embedded_url_analysis"] else 10
    }

    if classification == "DANGEROUS":
        actions = [
            "Mark as Phishing / Spam in your email client immediately.",
            "DO NOT click any buttons or hyperlinks in the message.",
            "Do not open or preview any attachments.",
            "Contact your organization's IT security team or the reported company through their verified portal."
        ]
        summary = "Dangerous phishing email detected. Evidence of sender spoofing or malicious payload delivery."
    elif classification == "SUSPICIOUS":
        actions = [
            "Inspect the sender's full email address and SPF/DKIM headers.",
            "If in doubt, forward to your cybersecurity helpdesk.",
            "Do not click links; open a fresh browser tab and visit the service directly."
        ]
        summary = "Suspicious email signals detected. Sender identity or messaging triggers caution."
    else:
        actions = [
            "Email passes primary security criteria.",
            "Verify links before clicking as a baseline precaution."
        ]
        summary = "No anomalous spoofing or social engineering indicators found."

    return {
        "input": f"From: {sender}\nSubject: {subject}",
        "type": "email",
        "sender": sender,
        "subject": subject,
        "risk_score": combined_score,
        "classification": classification,
        "confidence": round(86.0 + (abs(combined_score - 50) * 0.27), 1),
        "summary": summary,
        "reasons": reasons if reasons else [{"factor": "Sender & Content Trust", "severity": "SAFE", "description": "Sender headers and email body exhibit valid, trustworthy characteristics."}],
        "factors": factors,
        "highlights": list(set(highlights)),
        "embedded_url_analysis": body_analysis.get("embedded_url_analysis"),
        "actions": actions,
        "analyzed_at": datetime.utcnow().isoformat()
    }
