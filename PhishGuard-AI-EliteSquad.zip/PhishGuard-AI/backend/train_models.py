"""
PhishGuard AI - ML Model Trainer
Trains lightweight, fast, explainable scikit-learn models for:
1. URL Phishing Detection (Feature Extraction + Random Forest / Gradient Boosting / Logistic Regression)
2. Scam Message / Text Classification (TF-IDF + MultinomialNB / Logistic Regression)
"""

import os
import re
import math
import joblib
import numpy as np
from urllib.parse import urlparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline

MODEL_DIR = os.path.join(os.path.dirname(__file__), "saved_models")
os.makedirs(MODEL_DIR, exist_ok=True)

# -------------------------------------------------------------
# 1. URL FEATURE EXTRACTION HELPER
# -------------------------------------------------------------
POPULAR_BRANDS = [
    "paypal", "apple", "microsoft", "google", "amazon", "netflix",
    "chase", "wellsfargo", "bankofamerica", "sbi", "hdfc", "icici",
    "binance", "coinbase", "meta", "instagram", "facebook", "whatsapp",
    "fedex", "dhl", "usps", "telegram", "twitter", "linkedin", "dropbox"
]

SUSPICIOUS_TLDS = {
    "xyz", "top", "buzz", "club", "tk", "ml", "ga", "cf", "gq",
    "work", "icu", "sbs", "cfd", "click", "link", "monster", "online",
    "site", "rest", "cam", "kim", "fit", "surf", "cn", "ru"
}

def extract_url_features(url: str) -> list:
    """Extract numeric features from a URL for machine learning."""
    if not url.startswith(("http://", "https://")):
        url = "http://" + url
    
    parsed = urlparse(url)
    hostname = (parsed.hostname or "").lower()
    path = parsed.path.lower()
    full_url = url.lower()
    
    length = len(full_url)
    host_length = len(hostname)
    num_dots = hostname.count(".")
    num_hyphens = hostname.count("-")
    num_at = full_url.count("@")
    num_question = full_url.count("?")
    num_equal = full_url.count("=")
    num_slashes = full_url.count("/")
    
    # Check if host is raw IP address
    is_ip = 1.0 if re.match(r"^(\d{1,3}\.){3}\d{1,3}$", hostname) else 0.0
    
    # Entropy of hostname
    prob = [float(hostname.count(c)) / len(hostname) for c in set(hostname)] if hostname else [0]
    entropy = -sum(p * math.log(p, 2) for p in prob) if hostname else 0.0
    
    # Subdomain depth
    subdomains = hostname.split(".")
    tld = subdomains[-1] if len(subdomains) > 1 else ""
    is_suspicious_tld = 1.0 if tld in SUSPICIOUS_TLDS else 0.0
    subdomain_count = max(0, len(subdomains) - 2)
    
    # Brand impersonation in hostname or path
    brand_mentions = sum(1.0 for brand in POPULAR_BRANDS if brand in full_url)
    
    # Suspicious keywords
    keywords = ["login", "signin", "verify", "update", "bank", "account", "secure", "wallet", "free", "gift", "bonus", "claim"]
    keyword_count = sum(1.0 for kw in keywords if kw in full_url)
    
    is_https = 1.0 if parsed.scheme == "https" else 0.0
    
    return [
        length,
        host_length,
        num_dots,
        num_hyphens,
        num_at,
        num_question,
        num_equal,
        num_slashes,
        is_ip,
        entropy,
        is_suspicious_tld,
        subdomain_count,
        brand_mentions,
        keyword_count,
        is_https
    ]

# -------------------------------------------------------------
# 2. CURATED DATASETS FOR TRAINING
# -------------------------------------------------------------
def get_url_dataset():
    # Benign URLs
    benign = [
        "https://www.google.com/search?q=cybersecurity",
        "https://github.com/torvalds/linux",
        "https://en.wikipedia.org/wiki/Phishing",
        "https://www.amazon.com/dp/B08N5WRWNW",
        "https://www.microsoft.com/en-us/software-download/windows11",
        "https://stackoverflow.com/questions/tagged/python",
        "https://www.nytimes.com/section/technology",
        "https://www.apple.com/iphone-15-pro/",
        "https://docs.python.org/3/library/urllib.parse.html",
        "https://www.netflix.com/browse",
        "https://www.linkedin.com/feed/",
        "https://www.harvard.edu/programs/computer-science",
        "https://medium.com/@developer/building-secure-apis-2024",
        "https://www.reddit.com/r/MachineLearning/",
        "https://pypi.org/project/scikit-learn/",
        "https://fastapi.tiangolo.com/tutorial/",
        "https://developer.mozilla.org/en-US/docs/Web/HTTP",
        "https://www.spotify.com/us/premium/",
        "https://store.steampowered.com/app/1091500/Cyberpunk_2077/",
        "https://www.coursera.org/learn/machine-learning",
        "https://www.dropbox.com/business",
        "https://www.uber.com/us/en/ride/",
        "https://news.ycombinator.com/news",
        "https://gitlab.com/explore",
        "https://www.bbc.com/news/world"
    ]
    
    # Phishing / Malicious URLs
    phishing = [
        "http://paypal-security-verification-alert.xyz/login.php",
        "http://192.168.1.105/bankofamerica/secure/login.html",
        "http://appleid.apple.com.verify-billing-notice.top/account",
        "https://netflix-subscription-renew-account.buzz/billing",
        "http://chase-bank-verify-identity-urgently.cfd/signin",
        "http://login.microsoftonline.com.account-update.icu/auth",
        "http://sbi-kyc-pan-update-reward.sbs/netbanking.apk",
        "http://secure-amazon-order-refund-resolution.work/claim",
        "http://binance-wallet-recovery-airdrop.buzz/seed-phrase",
        "http://wellsfargo-security-locked.top/verify?token=92837",
        "http://whatsapp-gold-edition-download.xyz/update.apk",
        "http://fedex-package-customs-fee-payment.click/tracking",
        "http://usps-parcel-redelivery-notice.top/track/9382",
        "http://coinbase-authorization-required.rest/login",
        "http://free-iphone15-pro-giveaway-winner.buzz/claim-now",
        "http://paypa1-support-resolution-center.online/webapps/mpp",
        "http://bankofamerica-card-fraud-alert.link/ebanking",
        "http://telegram-premium-free-hack.sbs/login",
        "http://dhl-urgent-shipment-clearance.cfd/package",
        "http://hdfc-bank-netbanking-rewards-kyc.xyz/login.jsp",
        "http://210.45.12.89/netflix/login.php?customer=3829",
        "http://microsoft-outlook-webmail-update.buzz/office365",
        "http://google-drive-shared-confidential-doc.xyz/view",
        "http://instagram-copyright-infringement-strike.top/appeal",
        "http://crypto-doubler-instant-deposit.cam/invest"
    ]
    
    X = []
    y = []
    for u in benign:
        X.append(extract_url_features(u))
        y.append(0)
    for u in phishing:
        X.append(extract_url_features(u))
        y.append(1)
        
    return np.array(X), np.array(y)

def get_text_dataset():
    # Benign SMS / Emails / Messages
    benign_texts = [
        "Hey! Are you still joining us for lunch at 1 PM today? Let me know.",
        "Your Amazon order #402-91823 has shipped and will arrive on Friday. Track in your Amazon app.",
        "Hi Mom, I arrived safely at the university campus. Will call you tonight after dinner.",
        "Meeting reminder: Project Sync scheduled tomorrow at 10:00 AM in Conference Room B.",
        "Your OTP for verification is 492810. Valid for 5 minutes. Do not share with anyone.",
        "Google Security Alert: A new login was detected on your Chrome browser in California. If this was you, no action needed.",
        "Your flight ticket booking is confirmed. PNR: ABC928. Check-in opens 24 hours prior to departure.",
        "Thank you for attending HacXLerate 2026. The submission deadline is 4:00 PM today.",
        "Hi Team, please find attached the weekly sprint summary report and action items.",
        "Your doctor appointment is scheduled for Thursday, Oct 12 at 3:30 PM with Dr. Sharma.",
        "Spotify: Your monthly family subscription receipt for $16.99 is now available in your account.",
        "Hey, can you review the pull request on GitHub when you get a chance?",
        "Gym Membership update: Holiday hours will be in effect next Monday from 8 AM to 4 PM.",
        "Your package was successfully delivered to your front porch. Thank you for shopping with us.",
        "Here is the lecture slide deck from today's Advanced Algorithms class. Read chapter 4."
    ]
    
    # Scam / Phishing Texts
    scam_texts = [
        "URGENT: Your SBI Bank account has been BLOCKED due to pending KYC! Click here to update your PAN immediately: http://sbi-kyc-verify.xyz or your account will be permanently closed.",
        "FINAL NOTICE: You have an unpaid toll invoice of $12.50. Avoid a $150 court summons fee by paying right now at http://ezpass-toll-pay.top. Police complaint will be filed in 24 hours.",
        "Congratulations! Your mobile number won 1st prize in the 2026 International Lottery of $750,000! Send your bank details and fee to claim urgently.",
        "Dear customer, your Netflix account is on hold due to failed payment. Update card details within 12 hours to avoid suspension: http://netflix-billing-renew.buzz",
        "USPS Alert: We were unable to deliver your package due to incorrect street address. Confirm address and pay $1.99 redelivery fee: http://usps-tracking-parcel.top",
        "HR Notice: You have been selected for remote part-time job! Earn $500 to $1500 daily by simply liking YouTube videos. Contact our manager on Telegram @EarnCashCrypto now.",
        "Federal Tax Department: An immediate arrest warrant has been issued against your name for tax fraud. Call investigator officer at +1-800-FAKE-TAX to resolve immediately.",
        "Security Alert: Your PayPal account has been restricted due to suspicious activity. Verify your identity and password here: http://paypal-resolution-center.online",
        "URGENT: Your electricity connection will be disconnected tonight at 9:30 PM due to unpaid bill. Call electricity officer immediately at 9876543210.",
        "Your WhatsApp Gold edition is ready for update! Get spy features and free video calls. Download official APK: http://whatsapp-gold-hack.xyz",
        "Coinbase Security: Unauthorized withdrawal of 1.45 BTC initiated. If not requested, cancel immediately at http://coinbase-auth-cancel.rest",
        "Dear Student, you have received an emergency student relief grant of $2,500. Click here to enter your bank credentials and claim: http://edu-relief-grant.cfd",
        "DHL: Express shipment is waiting at customs clearance. An import duty fee of $3.50 is required before release. Pay here: http://dhl-customs-clearance.buzz",
        "Instagram Copyright Warning: Your account violates copyright laws and will be deleted in 24 hours. Submit appeal now: http://ig-copyright-appeal.top",
        "Bank Alert: $2,840 has been debited from your checking account. If not done by you, click here to reverse transaction: http://fraud-bank-dispute.click"
    ]
    
    X = benign_texts + scam_texts
    y = [0] * len(benign_texts) + [1] * len(scam_texts)
    return X, y

def train_and_save():
    print("Training URL Phishing Detection Model...")
    X_url, y_url = get_url_dataset()
    url_model = RandomForestClassifier(n_estimators=50, random_state=42, max_depth=8)
    url_model.fit(X_url, y_url)
    joblib.dump(url_model, os.path.join(MODEL_DIR, "url_classifier.joblib"))
    print("URL model trained and saved successfully.")

    print("Training Scam Message NLP Model...")
    X_text, y_text = get_text_dataset()
    text_pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), max_features=1000, lowercase=True)),
        ("clf", LogisticRegression(C=2.0, random_state=42))
    ])
    text_pipeline.fit(X_text, y_text)
    joblib.dump(text_pipeline, os.path.join(MODEL_DIR, "text_pipeline.joblib"))
    print("Text pipeline trained and saved successfully.")

if __name__ == "__main__":
    train_and_save()
