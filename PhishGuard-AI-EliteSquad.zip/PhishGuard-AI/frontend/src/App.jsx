import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import UrlScanner from './components/UrlScanner';
import MessageScanner from './components/MessageScanner';
import EmailScanner from './components/EmailScanner';
import ScanResultCard from './components/ScanResultCard';
import Dashboard from './components/Dashboard';
import ExtensionSimulator from './components/ExtensionSimulator';
import ApiPlayground from './components/ApiPlayground';
import PitchOverview from './components/PitchOverview';
import ReportModal from './components/ReportModal';
import { Globe, MessageSquareText, Mail, ShieldAlert, Sparkles, Terminal } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('scanner');
  const [scannerSubTab, setScannerSubTab] = useState('url');
  
  const [scanResult, setScanResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [backendHealthy, setBackendHealthy] = useState(true);

  const [stats, setStats] = useState(null);
  const [history, setHistory] = useState([]);
  const [demoCases, setDemoCases] = useState({ url: [], message: [], email: [] });

  const [reportingItem, setReportingItem] = useState(null);

  // Fetch initial telemetry and demo cases
  const fetchData = async () => {
    try {
      const [healthRes, demoRes, statsRes, histRes] = await Promise.all([
        fetch('/api/health').catch(() => null),
        fetch('/api/demo-cases').catch(() => null),
        fetch('/api/stats').catch(() => null),
        fetch('/api/history').catch(() => null),
      ]);

      if (healthRes && healthRes.ok) {
        setBackendHealthy(true);
      }
      if (demoRes && demoRes.ok) {
        const dData = await demoRes.json();
        setDemoCases(dData);
      }
      if (statsRes && statsRes.ok) {
        const sData = await statsRes.json();
        setStats(sData);
      }
      if (histRes && histRes.ok) {
        const hData = await histRes.json();
        setHistory(hData);
      }
    } catch (err) {
      console.warn('Backend connecting or offline:', err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // 1. URL Scan Action
  const handleScanUrl = async (url) => {
    setLoading(true);
    setScanResult(null);
    try {
      const res = await fetch('/api/scan/url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      if (!res.ok) throw new Error('Scan failed');
      const data = await res.json();
      setScanResult(data);
      fetchData(); // refresh dashboard stats & history
    } catch (err) {
      alert('Error connecting to backend scanner: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // 2. Message Scan Action
  const handleScanMessage = async (message) => {
    setLoading(true);
    setScanResult(null);
    try {
      const res = await fetch('/api/scan/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message })
      });
      if (!res.ok) throw new Error('Scan failed');
      const data = await res.json();
      setScanResult(data);
      fetchData();
    } catch (err) {
      alert('Error connecting to backend scanner: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // 3. Email Scan Action
  const handleScanEmail = async ({ sender, subject, body }) => {
    setLoading(true);
    setScanResult(null);
    try {
      const res = await fetch('/api/scan/email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sender, subject, body })
      });
      if (!res.ok) throw new Error('Scan failed');
      const data = await res.json();
      setScanResult(data);
      fetchData();
    } catch (err) {
      alert('Error connecting to backend scanner: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // Clear scan history
  const handleClearHistory = async () => {
    if (confirm('Clear all stored scan logs?')) {
      try {
        await fetch('/api/history', { method: 'DELETE' });
        fetchData();
      } catch (e) {
        console.error(e);
      }
    }
  };

  // Inspect scan from dashboard
  const handleInspectScan = (item) => {
    if (item.details) {
      setScanResult(item.details);
      setActiveTab('scanner');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#070a10] text-slate-100 selection:bg-cyan-500 selection:text-white">
      {/* Navigation */}
      <Navbar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        backendHealthy={backendHealthy} 
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* VIEW 1: SCANNER */}
        {activeTab === 'scanner' && (
          <div className="space-y-8">
            {/* Scanner Sub-Header */}
            <div className="text-center max-w-2xl mx-auto space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-800 text-cyan-300 text-xs font-mono">
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI-Powered Multi-Channel Threat Engine</span>
              </div>
              <h1 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight">
                Scan & Dissect Any Suspicious Digital Signal
              </h1>
              <p className="text-sm text-slate-400">
                Instant 0–100 risk scoring with Explainable AI reasoning across links, SMS, chat messages, and spoofed emails.
              </p>
            </div>

            {/* Sub-Tabs: URL / Message / Email */}
            <div className="flex justify-center">
              <div className="flex items-center gap-1.5 p-1.5 bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl">
                <button
                  onClick={() => { setScannerSubTab('url'); setScanResult(null); }}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold transition ${
                    scannerSubTab === 'url'
                      ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/25'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Globe className="w-4 h-4" />
                  <span>URL Scanner</span>
                </button>
                <button
                  onClick={() => { setScannerSubTab('message'); setScanResult(null); }}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold transition ${
                    scannerSubTab === 'message'
                      ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/25'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <MessageSquareText className="w-4 h-4" />
                  <span>SMS & Chat Scam</span>
                </button>
                <button
                  onClick={() => { setScannerSubTab('email'); setScanResult(null); }}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold transition ${
                    scannerSubTab === 'email'
                      ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/25'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Mail className="w-4 h-4" />
                  <span>Email Risk</span>
                </button>
              </div>
            </div>

            {/* Scanner Input Panels */}
            {!scanResult && (
              <div className="pt-2">
                {scannerSubTab === 'url' && (
                  <UrlScanner 
                    onScan={handleScanUrl} 
                    loading={loading} 
                    demoCases={demoCases?.url || []} 
                  />
                )}
                {scannerSubTab === 'message' && (
                  <MessageScanner 
                    onScan={handleScanMessage} 
                    loading={loading} 
                    demoCases={demoCases?.message || []} 
                  />
                )}
                {scannerSubTab === 'email' && (
                  <EmailScanner 
                    onScan={handleScanEmail} 
                    loading={loading} 
                    demoCases={demoCases?.email || []} 
                  />
                )}
              </div>
            )}

            {/* Explainable AI Result Display */}
            {scanResult && (
              <ScanResultCard 
                result={scanResult} 
                onReset={() => setScanResult(null)}
                onReport={(item) => setReportingItem(item)}
              />
            )}
          </div>
        )}

        {/* VIEW 2: THREAT DASHBOARD */}
        {activeTab === 'dashboard' && (
          <Dashboard 
            stats={stats} 
            history={history} 
            onRefresh={fetchData}
            onClearHistory={handleClearHistory}
            onInspectScan={handleInspectScan}
          />
        )}

        {/* VIEW 3: BROWSER EXTENSION & MOBILE SIMULATOR */}
        {activeTab === 'simulator' && (
          <ExtensionSimulator />
        )}

        {/* VIEW 4: API PLAYGROUND */}
        {activeTab === 'api' && (
          <ApiPlayground />
        )}

        {/* VIEW 5: PITCH & ARCHITECTURE */}
        {activeTab === 'pitch' && (
          <PitchOverview />
        )}
      </main>

      {/* Community Report Modal */}
      {reportingItem && (
        <ReportModal 
          targetItem={reportingItem} 
          onClose={() => setReportingItem(null)} 
        />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/80 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2 font-mono">
            <span className="text-slate-300 font-bold">PhishGuard AI</span>
            <span>•</span>
            <span>HacXLerate 2026 Hackathon MVP</span>
            <span>•</span>
            <span className="text-cyan-400">Team Elite Squad</span>
          </div>
          <div className="flex items-center gap-4">
            <span>FastAPI + scikit-learn + React + Explainable AI</span>
            <button 
              onClick={() => setActiveTab('pitch')}
              className="text-cyan-400 hover:text-cyan-300 hover:underline"
            >
              Problem & Architecture Pitch
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
