import React from 'react';
import { 
  ShieldCheck, AlertTriangle, Cpu, Layers, Sparkles, 
  Target, Award, Rocket, CheckCircle2, ArrowRight 
} from 'lucide-react';

export default function PitchOverview() {
  const steps = [
    { num: '01', title: 'INPUT', desc: 'User submits URL, SMS/Chat text, or Email' },
    { num: '02', title: 'ANALYZE', desc: 'Hybrid ML extraction + Transparent Rule Engine' },
    { num: '03', title: 'SCORE', desc: 'Unified 0–100 risk score with calibrated confidence' },
    { num: '04', title: 'EXPLAIN', desc: 'Plain-language XAI breakdown for non-technical users' },
    { num: '05', title: 'ACT', desc: 'Contextual response playbook (Avoid / Block / Report)' },
  ];

  const pillars = [
    {
      title: 'Explainability-First Security',
      desc: 'Most security tools are black-boxes. PhishGuard AI tells users EXACTLY why a message or site is dangerous in plain, accessible English.'
    },
    {
      title: 'Multi-Channel Coverage',
      desc: 'Phishing doesn’t stay in one app. We protect URLs, SMS, WhatsApp forwards, Telegram task scams, and Email spoofing under a unified engine.'
    },
    {
      title: 'Hybrid AI + Transparent Rules',
      desc: 'Machine learning catches emerging and unseen variations, while high-confidence heuristic rules instantly catch known deceptive patterns without false negatives.'
    },
    {
      title: 'Actionable Safety Guidance',
      desc: 'Instead of just flagging a threat, we guide vulnerable students and families on exact remediation steps to prevent financial loss.'
    }
  ];

  const roadmap = [
    { phase: 'Phase 1', title: 'Hackathon MVP (Live Now)', desc: 'Multi-channel URL/Text/Email detection engine, XAI breakdowns, and threat dashboard.' },
    { phase: 'Phase 2', title: 'Browser Extension', desc: 'Zero-latency pre-click interception on Chrome/Firefox with immediate threat blocking.' },
    { phase: 'Phase 3', title: 'Mobile Interceptor', desc: 'Privacy-preserving on-device SMS and messaging risk analysis for iOS and Android.' },
    { phase: 'Phase 4', title: 'Live Threat Intelligence', desc: 'Continuous automated updates of zero-day malicious domains and honeypot indicators.' },
    { phase: 'Phase 5', title: 'Regional Scale', desc: 'Multilingual NLP support (Hindi, Tamil, Spanish, etc.) and organization scam feeds.' }
  ];

  return (
    <div className="w-full max-w-5xl mx-auto space-y-10 animate-in fade-in duration-300">
      {/* Hero Banner */}
      <div className="p-8 md:p-10 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-700 shadow-2xl relative overflow-hidden">
        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-800 text-cyan-300 text-xs font-mono mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>HacXLerate 2026 • Team Elite Squad Presentation</span>
          </div>

          <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            PhishGuard AI: Explainable Digital Scam Defense
          </h2>
          <p className="text-slate-300 text-sm md:text-base mt-2 max-w-2xl leading-relaxed">
            One intelligent platform to detect, explain, and respond to digital scams across URLs, messaging apps, and email—empowering students, families, and organizations.
          </p>
        </div>
      </div>

      {/* 5-Step Architecture Flow */}
      <div className="p-8 rounded-3xl bg-slate-900/80 border border-slate-800">
        <h3 className="text-base font-bold text-white uppercase tracking-wider mb-6 flex items-center gap-2">
          <Layers className="w-5 h-5 text-cyan-400" />
          <span>How PhishGuard AI Works: 5-Stage Defense Flow</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {steps.map((step, idx) => (
            <div key={idx} className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 relative flex flex-col justify-between">
              <div>
                <span className="text-xs font-mono font-extrabold text-cyan-400">
                  {step.num}
                </span>
                <h4 className="text-sm font-bold text-white mt-1">
                  {step.title}
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-snug">
                  {step.desc}
                </p>
              </div>
              {idx < 4 && (
                <div className="hidden md:block absolute -right-3 top-1/2 -translate-y-1/2 z-10 text-cyan-500/50">
                  <ArrowRight className="w-5 h-5" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Problem & Innovation Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Problem */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 text-rose-400 text-sm font-bold uppercase tracking-wider">
            <AlertTriangle className="w-5 h-5" />
            <span>Problem Statement</span>
          </div>
          <ul className="space-y-2.5 text-xs text-slate-300">
            <li className="flex items-start gap-2">
              <span className="text-rose-400 font-bold shrink-0">•</span>
              <span>Scam messages & phishing links bypass traditional blocklists via burner domains and lookalike URLs.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-400 font-bold shrink-0">•</span>
              <span>Everyday non-technical users cannot decipher why a message or website is suspicious.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-400 font-bold shrink-0">•</span>
              <span>Students and seniors are frequently targeted by fake internship grants, KYC freezes, and lottery fraud.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-400 font-bold shrink-0">•</span>
              <span>Current enterprise security tooling is overly complex, fragmented, and lacks plain-language explainability.</span>
            </li>
          </ul>
        </div>

        {/* Pillars / Innovation */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 text-cyan-400 text-sm font-bold uppercase tracking-wider">
            <Cpu className="w-5 h-5" />
            <span>Key Innovation & Differentiation</span>
          </div>
          <div className="space-y-3">
            {pillars.map((p, idx) => (
              <div key={idx} className="p-2.5 rounded-xl bg-slate-950/50 border border-slate-800/80">
                <h5 className="text-xs font-bold text-white">{p.title}</h5>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Product Roadmap */}
      <div className="p-8 rounded-3xl bg-slate-900/80 border border-slate-800">
        <h3 className="text-base font-bold text-white uppercase tracking-wider mb-6 flex items-center gap-2">
          <Rocket className="w-5 h-5 text-cyan-400" />
          <span>Product Evolution Roadmap</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {roadmap.map((item, idx) => (
            <div 
              key={idx} 
              className={`p-4 rounded-2xl border ${
                idx === 0 
                  ? 'bg-cyan-950/30 border-cyan-500/50' 
                  : 'bg-slate-950/60 border-slate-800'
              }`}
            >
              <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-cyan-400">
                {item.phase}
              </span>
              <h4 className="text-xs font-bold text-white mt-1">
                {item.title}
              </h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Code Export & Download Card */}
      <div className="p-6 md:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div>
          <span className="text-[11px] font-mono uppercase tracking-widest text-cyan-400 font-semibold block mb-1">
            Complete Submission Package
          </span>
          <h3 className="text-xl font-bold text-white">
            Export & Download Entire PhishGuard AI Codebase
          </h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Download the complete source code (.zip) including FastAPI backend, scikit-learn ML models, React UI, and test suites for hackathon evaluation and deployment.
          </p>
        </div>

        <a
          href="/api/download-project"
          download="PhishGuard-AI-EliteSquad.zip"
          className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs uppercase tracking-wider transition shadow-lg shadow-cyan-600/30 flex items-center gap-2.5 shrink-0"
        >
          <span>Download Project (.ZIP)</span>
        </a>
      </div>
    </div>
  );
}
