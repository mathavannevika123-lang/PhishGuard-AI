import React, { useState } from 'react';
import { 
  Laptop, Smartphone, ShieldAlert, ShieldCheck, AlertTriangle, 
  ArrowLeft, Lock, ExternalLink, Bell, RefreshCw, CheckCircle2 
} from 'lucide-react';

export default function ExtensionSimulator() {
  const [activeMode, setActiveMode] = useState('browser'); // 'browser' or 'mobile'
  const [browserUrl, setBrowserUrl] = useState('http://paypa1-security-login.xyz/auth');
  const [blocked, setBlocked] = useState(true);
  const [mobileAlertOpen, setMobileAlertOpen] = useState(true);

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Top Description */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
            <span>Client End-Point Integrations Simulator</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Experience how PhishGuard AI protects everyday users directly inside the web browser & on mobile devices in real time
          </p>
        </div>

        {/* Mode Toggle */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-2xl border border-slate-800">
          <button
            onClick={() => setActiveMode('browser')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition ${
              activeMode === 'browser'
                ? 'bg-cyan-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Laptop className="w-4 h-4" />
            <span>Browser Extension Mode</span>
          </button>
          <button
            onClick={() => setActiveMode('mobile')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition ${
              activeMode === 'mobile'
                ? 'bg-cyan-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Mobile Guard Mode</span>
          </button>
        </div>
      </div>

      {activeMode === 'browser' ? (
        /* Browser Extension Simulation */
        <div className="rounded-3xl border border-slate-700 bg-slate-950 overflow-hidden shadow-2xl">
          {/* Chrome Top Bar */}
          <div className="bg-slate-900 border-b border-slate-800 p-3 flex items-center gap-3">
            <div className="flex items-center gap-1.5 ml-1">
              <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
            </div>

            {/* Address Bar */}
            <div className="flex-1 flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs font-mono">
              <span className="text-red-400">http://</span>
              <span className="text-slate-200 flex-1 truncate">{browserUrl}</span>
              
              {/* PhishGuard Extension Icon in browser toolbar */}
              <div className="flex items-center gap-1.5 bg-red-950/80 border border-red-800/80 px-2 py-0.5 rounded text-[11px] text-red-300">
                <ShieldAlert className="w-3 h-3 text-red-400 animate-pulse" />
                <span>PhishGuard (Blocked)</span>
              </div>
            </div>

            <button 
              onClick={() => setBlocked(!blocked)}
              className="text-xs text-slate-400 hover:text-cyan-400 px-2 py-1 rounded transition"
              title="Toggle Block Screen"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Browser Content Area */}
          <div className="min-h-[460px] p-8 flex items-center justify-center relative bg-gradient-to-b from-slate-950 via-[#0d131f] to-slate-950">
            {blocked ? (
              /* Interception Warning Screen */
              <div className="max-w-xl w-full p-8 rounded-3xl bg-slate-900/90 border border-red-500/40 shadow-2xl backdrop-blur-xl animate-in zoom-in-95 duration-300 text-center">
                <div className="w-16 h-16 rounded-2xl bg-red-500/20 border border-red-500/40 flex items-center justify-center mx-auto mb-4 text-red-400">
                  <ShieldAlert className="w-9 h-9" />
                </div>

                <div className="inline-block px-3 py-1 rounded-full text-xs font-mono font-bold bg-red-500/20 text-red-300 border border-red-500/30 uppercase tracking-widest mb-2">
                  DANGEROUS SITE INTERCEPTED • RISK SCORE: 98/100
                </div>

                <h3 className="text-xl font-bold text-white mb-2">
                  PhishGuard AI Blocked an Impersonation Attempt
                </h3>

                <p className="text-xs text-slate-300 leading-relaxed mb-6">
                  The website you are attempting to visit (<span className="text-red-400 font-mono font-semibold">{browserUrl}</span>) has been identified as a credential harvesting phishing replica targeting <strong className="text-white">PayPal</strong>.
                </p>

                {/* Threat indicators */}
                <div className="text-left bg-slate-950/80 p-4 rounded-2xl border border-slate-800 mb-6 space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-slate-300">
                    <span className="text-red-400 font-bold">✕</span>
                    <span><strong>Typosquatting:</strong> Domain substitutes characters to mimic real service</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <span className="text-red-400 font-bold">✕</span>
                    <span><strong>High-risk burner TLD:</strong> .xyz extension flagged in global threat lists</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <span className="text-red-400 font-bold">✕</span>
                    <span><strong>Unencrypted:</strong> Transmits credentials over plain HTTP</span>
                  </div>
                </div>

                {/* Safety buttons */}
                <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                  <button
                    onClick={() => {
                      setBrowserUrl('https://www.paypal.com');
                      setBlocked(false);
                    }}
                    className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs shadow-lg shadow-cyan-600/30 transition flex items-center justify-center gap-2"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Go to Legitimate Website (Safe)</span>
                  </button>
                  <button
                    onClick={() => setBlocked(false)}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs transition"
                  >
                    Bypass Warning (Unsafe)
                  </button>
                </div>
              </div>
            ) : (
              /* Normal Webpage when safe */
              <div className="text-center p-8">
                <CheckCircle2 className="w-16 h-16 text-emerald-400 mx-auto mb-3" />
                <h3 className="text-lg font-bold text-white">Safe Official Website Loaded</h3>
                <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                  You are browsing {browserUrl}. PhishGuard AI verified official digital certificate & domain ownership.
                </p>
                <button
                  onClick={() => {
                    setBrowserUrl('http://paypa1-security-login.xyz/auth');
                    setBlocked(true);
                  }}
                  className="mt-6 px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:bg-slate-700 transition"
                >
                  Simulate Phishing Link Click Again
                </button>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Mobile Simulator */
        <div className="flex justify-center p-6">
          <div className="w-[340px] rounded-[40px] border-4 border-slate-700 bg-slate-950 p-4 shadow-2xl relative">
            {/* Phone Speaker & Camera */}
            <div className="w-28 h-4 bg-slate-800 rounded-full mx-auto mb-4" />

            {/* Simulated Lock Screen / Chat Screen */}
            <div className="space-y-4 pt-2">
              <div className="text-center">
                <span className="text-3xl font-extrabold text-white font-mono">09:41</span>
                <span className="text-[11px] text-slate-400 block">Thursday, October 8</span>
              </div>

              {/* PhishGuard Mobile Push Notification */}
              {mobileAlertOpen ? (
                <div className="p-3.5 rounded-2xl bg-slate-900/95 border border-red-500/50 shadow-xl animate-in slide-in-from-top-4 duration-300">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-1.5 text-red-400 text-xs font-bold">
                      <ShieldAlert className="w-3.5 h-3.5" />
                      <span>PHISHGUARD SHIELD</span>
                    </div>
                    <span className="text-[10px] text-slate-400">now</span>
                  </div>

                  <h4 className="text-xs font-bold text-white">
                    🚨 High-Risk SMS Threat Detected!
                  </h4>
                  <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                    Sender claiming to be <strong>SBI Bank</strong> asking to update PAN KYC via link. This is a credential theft scam.
                  </p>

                  <div className="mt-2.5 pt-2 border-t border-slate-800 flex justify-end gap-2">
                    <button 
                      onClick={() => setMobileAlertOpen(false)}
                      className="text-[10px] text-slate-400 px-2 py-0.5 rounded hover:text-slate-200"
                    >
                      Dismiss
                    </button>
                    <button 
                      onClick={() => alert("Sender blocked and reported to national cybercrime registry.")}
                      className="text-[10px] px-2.5 py-1 rounded bg-red-600 hover:bg-red-500 text-white font-semibold transition"
                    >
                      Block & Report
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setMobileAlertOpen(true)}
                  className="w-full p-2.5 rounded-xl bg-slate-900 text-slate-400 text-xs hover:text-slate-200 border border-slate-800 transition"
                >
                  + Trigger New Incoming SMS Scam Alert
                </button>
              )}

              {/* Mock Incoming SMS Bubble */}
              <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
                <div className="text-[10px] text-slate-400 uppercase font-mono mb-1">
                  SMS from: +91 98210-91823
                </div>
                <p className="text-[11px] text-slate-200">
                  URGENT: Your SBI Account will be blocked today due to pending KYC. Click http://sbi-kyc-verify.xyz to submit PAN card details.
                </p>
              </div>
            </div>

            {/* Bottom Home Indicator */}
            <div className="w-32 h-1 bg-slate-600 rounded-full mx-auto mt-12" />
          </div>
        </div>
      )}
    </div>
  );
}
