import React from 'react';

export default function RiskGauge({ score, classification, confidence }) {
  // Normalize score between 0 and 100
  const validScore = Math.max(0, Math.min(100, score || 0));
  
  // Circumference for r=54: 2 * PI * 54 = ~339.29
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (validScore / 100) * circumference;

  let colorClass = 'text-emerald-500';
  let bgGlow = 'rgba(16, 185, 129, 0.2)';
  let badgeBg = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
  let badgeIcon = '✓';

  if (classification === 'DANGEROUS' || validScore >= 70) {
    colorClass = 'text-red-500';
    bgGlow = 'rgba(239, 68, 68, 0.25)';
    badgeBg = 'bg-red-500/10 text-red-400 border-red-500/30';
    badgeIcon = '⚠';
  } else if (classification === 'SUSPICIOUS' || validScore >= 30) {
    colorClass = 'text-amber-500';
    bgGlow = 'rgba(245, 158, 11, 0.25)';
    badgeBg = 'bg-amber-500/10 text-amber-400 border-amber-500/30';
    badgeIcon = '⚡';
  }

  return (
    <div className="flex flex-col items-center justify-center p-6 bg-slate-900/60 rounded-2xl border border-slate-800 relative overflow-hidden">
      {/* Background ambient radial glow */}
      <div 
        className="absolute w-40 h-40 rounded-full blur-3xl pointer-events-none transition-all duration-700"
        style={{ backgroundColor: bgGlow }}
      />

      <div className="relative w-36 h-36 flex items-center justify-center">
        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 130 130">
          {/* Track background */}
          <circle
            cx="65"
            cy="65"
            r={radius}
            stroke="currentColor"
            strokeWidth="10"
            fill="transparent"
            className="text-slate-800"
          />
          {/* Animated score ring */}
          <circle
            cx="65"
            cy="65"
            r={radius}
            stroke="currentColor"
            strokeWidth="10"
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className={`${colorClass} transition-all duration-1000 ease-out`}
          />
        </svg>

        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="text-4xl font-extrabold tracking-tight text-white font-mono">
            {validScore}
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-medium">
            / 100 Risk
          </span>
        </div>
      </div>

      <div className="mt-4 flex flex-col items-center gap-1.5">
        <div className={`px-4 py-1 rounded-full text-xs font-bold tracking-wider uppercase border flex items-center gap-1.5 ${badgeBg}`}>
          <span>{badgeIcon}</span>
          <span>{classification}</span>
        </div>
        {confidence && (
          <span className="text-xs text-slate-400 font-mono">
            AI Confidence: <strong className="text-slate-300">{confidence}%</strong>
          </span>
        )}
      </div>
    </div>
  );
}
