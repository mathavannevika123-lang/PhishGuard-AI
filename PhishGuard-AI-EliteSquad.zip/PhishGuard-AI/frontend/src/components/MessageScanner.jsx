import React, { useState } from 'react';
import { MessageSquareText, Sparkles, ArrowRight, AlertCircle, ShieldAlert } from 'lucide-react';

export default function MessageScanner({ onScan, loading, demoCases }) {
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!message.trim()) {
      setError('Please enter or paste a message to analyze');
      return;
    }
    setError('');
    onScan(message.trim());
  };

  const handleSelectDemo = (caseItem) => {
    setMessage(caseItem.value);
    setError('');
    onScan(caseItem.value);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* Demo Cases Bar */}
      {demoCases && demoCases.length > 0 && (
        <div className="mb-6 p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md">
          <div className="flex items-center gap-2 mb-2.5">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Quick Judge Presets (1-Click Test):
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {demoCases.map((demo) => {
              const badgeStyle = 
                demo.tier === 'SAFE' ? 'border-emerald-500/40 hover:bg-emerald-500/10 text-emerald-300' :
                demo.tier === 'SUSPICIOUS' ? 'border-amber-500/40 hover:bg-amber-500/10 text-amber-300' :
                'border-red-500/40 hover:bg-red-500/10 text-red-300';
              
              return (
                <button
                  key={demo.id}
                  type="button"
                  onClick={() => handleSelectDemo(demo)}
                  className={`text-xs px-3 py-1.5 rounded-xl border bg-slate-950/60 font-medium transition flex items-center gap-2 ${badgeStyle}`}
                  title={demo.description}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-current" />
                  <span>{demo.title}</span>
                  <span className="text-[10px] opacity-70 uppercase tracking-wider font-mono">[{demo.tier}]</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Main Text Input Form */}
      <form onSubmit={handleSubmit} className="p-6 bg-slate-900/90 border border-slate-800 focus-within:border-cyan-500/60 rounded-3xl shadow-xl transition-all duration-300">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2 text-cyan-400 text-sm font-semibold">
            <MessageSquareText className="w-5 h-5" />
            <span>SMS & Chat Message Content</span>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {message.length} characters
          </span>
        </div>

        <textarea
          rows={5}
          value={message}
          onChange={(e) => {
            setMessage(e.target.value);
            if (error) setError('');
          }}
          placeholder="Paste SMS text, WhatsApp forward, or messaging app conversation here... (e.g. 'URGENT: Your bank account will be blocked within 24 hours. Click link to verify KYC...')"
          className="w-full bg-slate-950/70 border border-slate-800 rounded-2xl p-4 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 text-sm md:text-base resize-none"
          disabled={loading}
        />

        {error && (
          <div className="mt-2 flex items-center gap-2 text-rose-400 text-xs">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        )}

        <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-400 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>Scans for urgency pressure, extortion threats, financial bait, and credential harvesting</span>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-sm transition shadow-lg shadow-cyan-600/30 flex items-center justify-center gap-2 shrink-0 disabled:opacity-50"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Running NLP Pipeline...</span>
              </>
            ) : (
              <>
                <span>Analyze Message</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
