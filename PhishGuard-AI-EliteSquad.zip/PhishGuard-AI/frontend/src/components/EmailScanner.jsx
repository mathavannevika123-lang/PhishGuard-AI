import React, { useState } from 'react';
import { Mail, Sparkles, ArrowRight, AlertCircle, ShieldCheck } from 'lucide-react';

export default function EmailScanner({ onScan, loading, demoCases }) {
  const [sender, setSender] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!body.trim()) {
      setError('Please provide email body content to analyze');
      return;
    }
    setError('');
    onScan({
      sender: sender.trim() || 'Unknown Sender <unknown@domain.com>',
      subject: subject.trim() || '(No Subject)',
      body: body.trim()
    });
  };

  const handleSelectDemo = (caseItem) => {
    setSender(caseItem.sender || '');
    setSubject(caseItem.subject || '');
    setBody(caseItem.body || '');
    setError('');
    onScan({
      sender: caseItem.sender,
      subject: caseItem.subject,
      body: caseItem.body
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* Demo Cases Bar */}
      {demoCases && demoCases.length > 0 && (
        <div className="mb-6 p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md">
          <div className="flex items-center gap-2 mb-2.5">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Quick Judge Presets (1-Click Test):
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {demoCases.map((demo) => {
              const badgeStyle = 
                demo.tier === 'SAFE' ? 'border-emerald-500/40 hover:bg-emerald-500/10 text-emerald-300' :
                demo.tier === 'SUSPICIOUS' ? 'border-amber-500/40 hover:bg-amber-500/10 text-amber-300' :
                'border-red-500/40 hover:bg-red-500/10 text-red-300';
              
              return (
                <button
                  key={demo.id}
                  type="button"
                  onClick={() => handleSelectDemo(demo)}
                  className={`text-xs px-3 py-1.5 rounded-xl border bg-slate-950/60 font-medium transition flex items-center gap-2 ${badgeStyle}`}
                  title={demo.description}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-current" />
                  <span>{demo.title}</span>
                  <span className="text-[10px] opacity-70 uppercase tracking-wider font-mono">[{demo.tier}]</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Main Email Input Form */}
      <form onSubmit={handleSubmit} className="p-6 bg-slate-900/90 border border-slate-800 focus-within:border-cyan-500/60 rounded-3xl shadow-xl transition-all duration-300 space-y-4">
        <div className="flex items-center gap-2 text-cyan-400 text-sm font-semibold mb-1">
          <Mail className="w-5 h-5" />
          <span>Email Header & Content Inspector</span>
        </div>

        {/* Sender Line */}
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Sender Header (Display Name & Email Address):
          </label>
          <input
            type="text"
            value={sender}
            onChange={(e) => setSender(e.target.value)}
            placeholder="e.g. Netflix Billing Support <billing@netflix-account-resolution.top>"
            className="w-full bg-slate-950/70 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
            disabled={loading}
          />
        </div>

        {/* Subject Line */}
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Email Subject Line:
          </label>
          <input
            type="text"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="e.g. URGENT: Your account access has been revoked"
            className="w-full bg-slate-950/70 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-medium"
            disabled={loading}
          />
        </div>

        {/* Email Body */}
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Email Body Content:
          </label>
          <textarea
            rows={5}
            value={body}
            onChange={(e) => {
              setBody(e.target.value);
              if (error) setError('');
            }}
            placeholder="Paste full email text including any links or call-to-action notices..."
            className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-4 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 text-sm resize-none"
            disabled={loading}
          />
        </div>

        {error && (
          <div className="flex items-center gap-2 text-rose-400 text-xs">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        )}

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-800/80">
          <div className="text-xs text-slate-400 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>Analyzes sender display name spoofing, BEC signals, and embedded link hazards</span>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-sm transition shadow-lg shadow-cyan-600/30 flex items-center justify-center gap-2 shrink-0 disabled:opacity-50"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Auditing Email Integrity...</span>
              </>
            ) : (
              <>
                <span>Analyze Email</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
