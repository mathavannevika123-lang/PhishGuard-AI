import React, { useState } from 'react';
import { Flag, X, CheckCircle2 } from 'lucide-react';

export default function ReportModal({ targetItem, onClose }) {
  const [threatType, setThreatType] = useState('Phishing Link');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await fetch('/api/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          threat_type: threatType,
          target_content: targetItem?.input || 'N/A',
          notes: notes
        })
      });
      setSubmitted(true);
      setTimeout(() => {
        onClose();
      }, 1800);
    } catch (e) {
      setSubmitted(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="text-center py-6">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-white">Report Submitted!</h3>
            <p className="text-xs text-slate-400 mt-1">
              Thank you for contributing to the community threat defense network.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex items-center gap-2 text-rose-400 text-sm font-semibold">
              <Flag className="w-4 h-4" />
              <span>Report Malicious Threat / Scam</span>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Target Content:</label>
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 font-mono break-all max-h-20 overflow-y-auto">
                {targetItem?.input || 'Selected Scan Item'}
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Report Category:</label>
              <select
                value={threatType}
                onChange={(e) => setThreatType(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="Phishing Link">Phishing Link / Lookalike Domain</option>
                <option value="SMS Scam">SMS / Chat Smishing</option>
                <option value="Email Spoofing">Email Spoofing / BEC</option>
                <option value="False Positive">False Positive (Item is Safe)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Additional Context (Optional):</label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Where did you receive this link? Any details regarding impersonation..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 resize-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:bg-slate-700 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold transition flex items-center gap-1.5"
              >
                {loading ? 'Submitting...' : 'Submit Threat Report'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
