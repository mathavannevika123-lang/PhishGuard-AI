import React, { useState } from 'react';
import { Globe, ArrowRight, Sparkles, Shield, AlertCircle } from 'lucide-react';

export default function UrlScanner({ onScan, loading, demoCases }) {
  const [url, setUrl] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!url.trim()) {
      setError('Please provide a URL to scan');
      return;
    }
    setError('');
    onScan(url.trim());
  };

  const handleSelectDemo = (caseItem) => {
    setUrl(caseItem.value);
    setError('');
    onScan(caseItem.value);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* Demo Cases Bar */}
      {demoCases && demoCases.length > 0 && (
        <div className="mb-6 p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md">
          <div className="flex items-center gap-2 mb-2.5">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Quick Judge Presets (1-Click Test):
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {demoCases.map((demo) => {
              const badgeStyle = 
                demo.tier === 'SAFE' ? 'border-emerald-500/40 hover:bg-emerald-500/10 text-emerald-300' :
                demo.tier === 'SUSPICIOUS' ? 'border-amber-500/40 hover:bg-amber-500/10 text-amber-300' :
                'border-red-500/40 hover:bg-red-500/10 text-red-300';
              
              return (
                <button
                  key={demo.id}
                  type="button"
                  onClick={() => handleSelectDemo(demo)}
                  className={`text-xs px-3 py-1.5 rounded-xl border bg-slate-950/60 font-medium transition flex items-center gap-2 ${badgeStyle}`}
                  title={demo.description}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-current" />
                  <span>{demo.title}</span>
                  <span className="text-[10px] opacity-70 uppercase tracking-wider font-mono">[{demo.tier}]</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Main Input Form */}
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative flex flex-col md:flex-row items-center gap-3 p-2 bg-slate-900/90 border border-slate-800 focus-within:border-cyan-500/60 rounded-2xl md:rounded-3xl shadow-xl transition-all duration-300">
          <div className="flex items-center gap-3 w-full px-4 py-3 md:py-2">
            <Globe className="w-6 h-6 text-cyan-400 shrink-0" />
            <input
              type="text"
              value={url}
              onChange={(e) => {
                setUrl(e.target.value);
                if (error) setError('');
              }}
              placeholder="Paste website link (e.g. paypal-security-verification.xyz or https://google.com)"
              className="w-full bg-transparent text-white placeholder-slate-500 focus:outline-none text-sm md:text-base font-mono"
              disabled={loading}
            />
            {url && (
              <button
                type="button"
                onClick={() => setUrl('')}
                className="text-xs text-slate-500 hover:text-slate-300 px-2"
              >
                Clear
              </button>
            )}
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full md:w-auto px-8 py-4 md:py-3.5 rounded-xl md:rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-sm transition shadow-lg shadow-cyan-600/30 flex items-center justify-center gap-2 shrink-0 disabled:opacity-50"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Scanning Threat Signals...</span>
              </>
            ) : (
              <>
                <span>Analyze URL</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>

        {error && (
          <div className="mt-3 flex items-center gap-2 text-rose-400 text-xs px-2">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        )}

        <div className="mt-3 flex items-center justify-between text-xs text-slate-400 px-2 font-mono">
          <span>AI Feature Extraction: Hostname Entropy • Typosquatting • TLD Risk • Protocol Security</span>
          <span>FastAPI + ML Hybrid</span>
        </div>
      </form>
    </div>
  );
}
