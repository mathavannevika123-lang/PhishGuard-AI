import React, { useState } from 'react';
import { 
  ShieldAlert, ShieldCheck, AlertTriangle, Activity, 
  BarChart3, RefreshCw, Trash2, Download, Search, Filter,
  Globe, MessageSquareText, Mail, Eye
} from 'lucide-react';

export default function Dashboard({ stats, history, onRefresh, onClearHistory, onInspectScan }) {
  const [filterType, setFilterType] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredHistory = (history || []).filter(item => {
    const matchesFilter = 
      filterType === 'ALL' ||
      item.classification?.toUpperCase() === filterType ||
      item.type?.toLowerCase() === filterType.toLowerCase();
    
    const matchesSearch = 
      !searchQuery || 
      item.input?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.summary?.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(history, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `phishguard_threat_history_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'url':
        return <Globe className="w-4 h-4 text-cyan-400" />;
      case 'message':
        return <MessageSquareText className="w-4 h-4 text-indigo-400" />;
      case 'email':
        return <Mail className="w-4 h-4 text-purple-400" />;
      default:
        return <Activity className="w-4 h-4 text-slate-400" />;
    }
  };

  const getTierBadge = (classification) => {
    switch (classification?.toUpperCase()) {
      case 'DANGEROUS':
        return 'bg-red-500/20 text-red-400 border-red-500/40';
      case 'SUSPICIOUS':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'SAFE':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto space-y-8 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
            <BarChart3 className="w-6 h-6 text-cyan-400" />
            <span>Cyber Threat Intelligence & Activity Dashboard</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Telemetry metrics, attack vector frequencies, and audit history across multi-channel scans
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onRefresh}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Stats</span>
          </button>
          <button
            onClick={handleExportJSON}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export JSON</span>
          </button>
          <button
            onClick={onClearHistory}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-red-950/40 hover:bg-red-900/40 text-red-300 text-xs font-semibold border border-red-800/40 transition"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Logs</span>
          </button>
        </div>
      </div>

      {/* Metrics Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Total Scanned</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-3xl font-extrabold text-white mt-2 font-mono">
            {stats?.total_scans || 0}
          </p>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Multi-channel telemetry
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-red-400 uppercase tracking-wider">Dangerous Threats</span>
            <ShieldAlert className="w-4 h-4 text-red-400" />
          </div>
          <p className="text-3xl font-extrabold text-red-400 mt-2 font-mono">
            {stats?.dangerous_count || 0}
          </p>
          <span className="text-[11px] text-red-300/70 mt-1 block">
            Blocked & quarantined
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-amber-400 uppercase tracking-wider">Suspicious Items</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-3xl font-extrabold text-amber-400 mt-2 font-mono">
            {stats?.suspicious_count || 0}
          </p>
          <span className="text-[11px] text-amber-300/70 mt-1 block">
            Flagged for review
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-emerald-400 uppercase tracking-wider">Safe & Clean</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-3xl font-extrabold text-emerald-400 mt-2 font-mono">
            {stats?.safe_count || 0}
          </p>
          <span className="text-[11px] text-emerald-300/70 mt-1 block">
            Zero threat indicators
          </span>
        </div>
      </div>

      {/* Threat Vectors & Channels Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Threat Vectors */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-slate-900/80 border border-slate-800">
          <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-4 flex items-center justify-between">
            <span>Observed Scam & Phishing Attack Vectors</span>
            <span className="text-xs font-mono text-cyan-400 font-normal">Active Heuristic Signatures</span>
          </h3>
          <div className="space-y-3.5">
            {(stats?.top_threat_vectors || []).map((vector, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">{vector.name}</span>
                  <span className="text-slate-400 font-mono">{vector.count} incidents</span>
                </div>
                <div className="w-full bg-slate-800/80 rounded-full h-2 overflow-hidden">
                  <div 
                    className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-500"
                    style={{ width: `${Math.min(100, Math.max(12, vector.count * 12))}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Protection Distribution */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">
              Channel Breakdown
            </h3>
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Globe className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs text-slate-300">URLs & Domains</span>
                </div>
                <span className="text-xs font-mono text-cyan-400 font-bold">
                  {stats?.channel_distribution?.url || 0}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <MessageSquareText className="w-4 h-4 text-indigo-400" />
                  <span className="text-xs text-slate-300">SMS & Chat Texts</span>
                </div>
                <span className="text-xs font-mono text-indigo-400 font-bold">
                  {stats?.channel_distribution?.message || 0}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Mail className="w-4 h-4 text-purple-400" />
                  <span className="text-xs text-slate-300">Email Analysis</span>
                </div>
                <span className="text-xs font-mono text-purple-400 font-bold">
                  {stats?.channel_distribution?.email || 0}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-slate-800/80 text-center">
            <span className="text-xs text-slate-400">Threat Detection Rate:</span>
            <div className="text-xl font-bold font-mono text-cyan-400 mt-0.5">
              {stats?.threat_detection_rate || 0}%
            </div>
          </div>
        </div>
      </div>

      {/* Audit History Log Table */}
      <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider">
              Scan Audit History Log
            </h3>
            <span className="text-xs text-slate-400">
              Showing {filteredHistory.length} of {history?.length || 0} entries
            </span>
          </div>

          {/* Search & Filter Controls */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search targets or summary..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-950/80 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-44 sm:w-56"
              />
            </div>

            <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800 text-xs">
              {['ALL', 'DANGEROUS', 'SUSPICIOUS', 'SAFE', 'URL', 'MESSAGE', 'EMAIL'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setFilterType(tab)}
                  className={`px-2.5 py-1 rounded-lg font-medium transition ${
                    filterType === tab 
                      ? 'bg-cyan-600 text-white' 
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* History Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] font-mono uppercase tracking-wider text-slate-400">
                <th className="py-3 px-3">Type</th>
                <th className="py-3 px-3">Target / Excerpt</th>
                <th className="py-3 px-3">Verdict</th>
                <th className="py-3 px-3">Risk Score</th>
                <th className="py-3 px-3">Timestamp</th>
                <th className="py-3 px-3 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs">
              {filteredHistory.length === 0 ? (
                <tr>
                  <td colSpan="6" className="text-center py-8 text-slate-500">
                    No scan entries matching the current filter.
                  </td>
                </tr>
              ) : (
                filteredHistory.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/30 transition">
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5">
                        {getTypeIcon(item.type)}
                        <span className="capitalize text-slate-300 font-mono text-[11px]">
                          {item.type}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-3 max-w-xs md:max-w-md">
                      <span className="text-slate-200 font-mono block truncate" title={item.input}>
                        {item.input}
                      </span>
                      <span className="text-[11px] text-slate-400 truncate block mt-0.5">
                        {item.summary}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border uppercase tracking-wider ${getTierBadge(item.classification)}`}>
                        {item.classification}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-mono font-bold text-slate-200">
                        {item.risk_score}
                      </span>
                      <span className="text-slate-500 font-mono text-[10px]">/100</span>
                    </td>
                    <td className="py-3 px-3 text-slate-400 font-mono text-[11px] whitespace-nowrap">
                      {item.created_at ? new Date(item.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Just now'}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => onInspectScan && onInspectScan(item)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                        title="Inspect Scan Details"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
