import React, { useState } from 'react';
import { Terminal, Send, Copy, Check, Code, Play } from 'lucide-react';

export default function ApiPlayground() {
  const [selectedEndpoint, setSelectedEndpoint] = useState('url');
  const [requestBody, setRequestBody] = useState(
    JSON.stringify({ url: "http://paypal-security-verification-alert.xyz/login.php" }, null, 2)
  );
  const [responseOutput, setResponseOutput] = useState(null);
  const [loading, setLoading] = useState(false);
  const [copiedSnippet, setCopiedSnippet] = useState(false);
  const [duration, setDuration] = useState(null);

  const endpointConfig = {
    url: {
      method: 'POST',
      path: '/api/scan/url',
      defaultBody: { url: "http://paypal-security-verification-alert.xyz/login.php" }
    },
    message: {
      method: 'POST',
      path: '/api/scan/message',
      defaultBody: { message: "URGENT: Your bank account will be blocked within 24 hours. Update KYC now at http://sbi-kyc.xyz" }
    },
    email: {
      method: 'POST',
      path: '/api/scan/email',
      defaultBody: {
        sender: "Netflix Support <billing@movie-renew-now.top>",
        subject: "Action Required: Payment Declined",
        body: "Your account is on hold. Renew billing details at http://netflix-renew.buzz"
      }
    },
    stats: {
      method: 'GET',
      path: '/api/stats',
      defaultBody: null
    }
  };

  const handleSelectEndpoint = (key) => {
    setSelectedEndpoint(key);
    const cfg = endpointConfig[key];
    setRequestBody(cfg.defaultBody ? JSON.stringify(cfg.defaultBody, null, 2) : '');
    setResponseOutput(null);
    setDuration(null);
  };

  const handleExecute = async () => {
    setLoading(true);
    setDuration(null);
    const startTime = performance.now();
    try {
      const cfg = endpointConfig[selectedEndpoint];
      let res;
      if (cfg.method === 'POST') {
        const parsed = JSON.parse(requestBody);
        res = await fetch(cfg.path, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(parsed)
        });
      } else {
        res = await fetch(cfg.path);
      }
      const data = await res.json();
      const endTime = performance.now();
      setDuration(Math.round(endTime - startTime));
      setResponseOutput(data);
    } catch (err) {
      setResponseOutput({ error: err.message || 'API request failed' });
    } finally {
      setLoading(false);
    }
  };

  const curlSnippet = selectedEndpoint === 'stats'
    ? `curl -X GET "http://localhost:8000/api/stats"`
    : `curl -X POST "http://localhost:8000${endpointConfig[selectedEndpoint].path}" \\
  -H "Content-Type: application/json" \\
  -d '${requestBody.replace(/\n/g, '').replace(/\s+/g, ' ')}'`;

  const pythonSnippet = selectedEndpoint === 'stats'
    ? `import requests

res = requests.get("http://localhost:8000/api/stats")
print(res.json())`
    : `import requests

payload = ${requestBody}
res = requests.post("http://localhost:8000${endpointConfig[selectedEndpoint].path}", json=payload)
print(res.json())`;

  const copyCode = (code) => {
    navigator.clipboard.writeText(code);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-in fade-in duration-300">
      <div>
        <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
          <Terminal className="w-6 h-6 text-cyan-400" />
          <span>Interactive REST API Playground & Integration Hub</span>
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Test backend endpoints directly or copy ready-to-run cURL / Python client code for automated threat detection
        </p>
      </div>

      {/* Endpoint Selector Tabs */}
      <div className="flex flex-wrap gap-2">
        {Object.entries(endpointConfig).map(([key, cfg]) => (
          <button
            key={key}
            onClick={() => handleSelectEndpoint(key)}
            className={`px-4 py-2 rounded-xl text-xs font-mono font-semibold transition border flex items-center gap-2 ${
              selectedEndpoint === key
                ? 'bg-cyan-600 border-cyan-500 text-white shadow-lg shadow-cyan-600/20'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className={cfg.method === 'POST' ? 'text-blue-300' : 'text-emerald-300'}>
              {cfg.method}
            </span>
            <span>{cfg.path}</span>
          </button>
        ))}
      </div>

      {/* Request & Response Split Screen */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Request Panel */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
                HTTP Request Body (JSON)
              </span>
              <span className="text-[11px] text-cyan-400 font-mono">
                {endpointConfig[selectedEndpoint].method} {endpointConfig[selectedEndpoint].path}
              </span>
            </div>

            {endpointConfig[selectedEndpoint].method === 'POST' ? (
              <textarea
                rows={10}
                value={requestBody}
                onChange={(e) => setRequestBody(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
              />
            ) : (
              <div className="p-8 text-center bg-slate-950/40 rounded-xl border border-slate-800/80 text-xs text-slate-500 font-mono">
                GET request takes no body payload. Click 'Send API Request' below.
              </div>
            )}
          </div>

          <div className="mt-4 flex items-center justify-between">
            <button
              onClick={handleExecute}
              disabled={loading}
              className="px-6 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition shadow-lg shadow-cyan-600/30 flex items-center gap-2 disabled:opacity-50"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{loading ? 'Executing...' : 'Send API Request'}</span>
            </button>
            {duration !== null && (
              <span className="text-xs font-mono text-emerald-400">
                ⚡ Latency: {duration} ms
              </span>
            )}
          </div>
        </div>

        {/* Response Panel */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
              Response Payload
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              {responseOutput ? 'Status: 200 OK' : 'Awaiting execution'}
            </span>
          </div>

          <pre className="flex-1 bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-300 overflow-auto max-h-[290px]">
            {responseOutput ? JSON.stringify(responseOutput, null, 2) : '// Response will appear here after execution...'}
          </pre>
        </div>
      </div>

      {/* Ready-to-use Code Snippets */}
      <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-white flex items-center gap-2">
            <Code className="w-4 h-4 text-cyan-400" />
            <span>Developer Integration Snippets (cURL / Python)</span>
          </span>
          <button
            onClick={() => copyCode(curlSnippet)}
            className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition"
          >
            {copiedSnippet ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSnippet ? 'Copied!' : 'Copy cURL'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <span className="text-[11px] text-slate-400 font-mono">cURL Command:</span>
            <pre className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-[11px] font-mono text-cyan-300 overflow-x-auto">
              {curlSnippet}
            </pre>
          </div>
          <div className="space-y-1.5">
            <span className="text-[11px] text-slate-400 font-mono">Python (requests library):</span>
            <pre className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-[11px] font-mono text-emerald-300 overflow-x-auto">
              {pythonSnippet}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
